# Swing Crazy Panel

Panel build for work with flatlaf and miglayout

## library used in this project
- flatlaf [link](https://github.com/JFormDesigner/FlatLaf.git)
- miglayout [link](https://github.com/mikaelgrev/miglayout.git)

## Screenshot

<img src="https://github.com/DJ-Raven/swing-crazy-panel/assets/58245926/38c8c8e8-6356-464f-b0fb-e8a89d6aae34" alt="sample dark" width="300"/>
&nbsp;
<img src="https://github.com/DJ-Raven/swing-crazy-panel/assets/58245926/61d86cdf-1a74-4d07-931d-07605dc78069" alt="sample light" width="300"/>

Use this bean pack library to build this ui [here](https://github.com/DJ-Raven/raven-bean-pack.git)
